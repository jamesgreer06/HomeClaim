load('HomeClaim')
setExtensionUnloadMode('HomeClaim', 'manual')