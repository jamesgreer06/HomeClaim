-- HomeClaim Client Plugin
-- Handles visual markers and map integration

log("I", "HomeClaim", "Client plugin loading...")

local markers = {}
local mapMarkers = {}

-- Create visual radius marker
local function createRadiusMarker(position, radius, name)
    -- Remove existing marker if any
    if markers[name] then
        removeRadiusMarker(name)
    end

    -- Create a circular marker using multiple objects
    local markerObjects = {}
    local segments = 32 -- Number of segments in the circle
    
    for i = 0, segments - 1 do
        local angle = (i / segments) * 2 * math.pi
        local x = position.x + math.cos(angle) * radius
        local y = position.y + math.sin(angle) * radius
        local z = position.z
        
        -- Create a small marker object at this point
        local markerName = "homeMarker_" .. name .. "_" .. i
        local marker = createObject("TSStatic")
        marker:setField("shapeName", 0, "art/shapes/interface/position_marker.dae")
        marker:setPosition(vec3(x, y, z))
        marker.scale = vec3(0.5, 0.5, 0.5)
        marker:setField("rotation", 0, "1 0 0 0")
        marker.useInstanceRenderData = true
        marker:setField("instanceColor", 0, "0 1 0 1") -- Green color
        marker:setField("collisionType", 0, "None")
        marker:setField("canSave", 0, "0")
        marker.canSave = false
        marker:registerObject(markerName)
        scenetree.MissionGroup:addObject(marker)
        
        table.insert(markerObjects, marker)
    end

    -- Create center marker
    local centerMarkerName = "homeCenter_" .. name
    local centerMarker = createObject("TSStatic")
    centerMarker:setField("shapeName", 0, "art/shapes/interface/position_marker.dae")
    centerMarker:setPosition(vec3(position.x, position.y, position.z))
    centerMarker.scale = vec3(1.5, 1.5, 1.5)
    centerMarker:setField("rotation", 0, "1 0 0 0")
    centerMarker.useInstanceRenderData = true
    centerMarker:setField("instanceColor", 0, "0 1 0 1") -- Green color
    centerMarker:setField("collisionType", 0, "None")
    centerMarker:setField("canSave", 0, "0")
    centerMarker.canSave = false
    centerMarker:registerObject(centerMarkerName)
    scenetree.MissionGroup:addObject(centerMarker)
    
    table.insert(markerObjects, centerMarker)

    markers[name] = {
        objects = markerObjects,
        position = position,
        radius = radius
    }
end

-- Remove radius marker
local function removeRadiusMarker(name)
    if markers[name] then
        for _, obj in ipairs(markers[name].objects) do
            if obj and obj:isValid() then
                obj:delete()
            end
        end
        markers[name] = nil
    end
end

-- Add map marker
local function addMapMarker(position, name)
    -- Use BeamNG's map system to add a marker
    -- Try different map APIs that might be available
    if gui and gui.getMap then
        local map = gui.getMap()
        if map and map.addMarker then
            local markerId = map.addMarker({
                position = position,
                label = name,
                color = {0, 1, 0, 1} -- Green
            })
            mapMarkers[name] = markerId
            return
        end
    end
    
    -- Alternative: Use mission editor markers
    if scenetree and scenetree.MissionGroup then
        -- Create a visible marker object that shows on map
        local markerName = "mapMarker_" .. name
        local marker = createObject("TSStatic")
        marker:setField("shapeName", 0, "art/shapes/interface/position_marker.dae")
        marker:setPosition(vec3(position.x, position.y, position.z + 5)) -- Slightly elevated
        marker.scale = vec3(2, 2, 2)
        marker:setField("rotation", 0, "1 0 0 0")
        marker.useInstanceRenderData = true
        marker:setField("instanceColor", 0, "0 1 0 1") -- Green color
        marker:setField("collisionType", 0, "None")
        marker:setField("canSave", 0, "0")
        marker.canSave = false
        marker:registerObject(markerName)
        scenetree.MissionGroup:addObject(marker)
        mapMarkers[name] = marker
        log("I", "HomeClaim", "Map marker created for: " .. name)
    else
        log("W", "HomeClaim", "Could not create map marker for: " .. name)
    end
end

-- Remove map marker
local function removeMapMarker(name)
    if mapMarkers[name] and map and map.removeMarker then
        map.removeMarker(mapMarkers[name])
        mapMarkers[name] = nil
    end
end

-- Update all map markers
local function updateMapMarkers(homes)
    -- Clear existing markers
    for name, _ in pairs(mapMarkers) do
        removeMapMarker(name)
    end
    mapMarkers = {}

    -- Add new markers
    for playerId, home in pairs(homes) do
        addMapMarker(home.position, home.name)
    end
end

-- Restore vehicle at saved position
local function restoreVehicle(vehicleData)
    if not vehicleData then
        return
    end
    
    local vehicleId = vehicleData.vehicleId
    local position = vehicleData.position
    local rotation = vehicleData.rotation
    local config = vehicleData.config
    
    -- Get the vehicle object
    local vehicle = be:getObjectByID(vehicleId)
    if vehicle then
        -- Set position
        if position then
            vehicle:setPosition(vec3(position.x, position.y, position.z))
        end
        
        -- Set rotation if available
        if rotation then
            if type(rotation) == "table" and rotation.x then
                vehicle:setRotation(quat(rotation.x, rotation.y, rotation.z, rotation.w))
            elseif type(rotation) == "table" and #rotation >= 4 then
                vehicle:setRotation(quat(rotation[1], rotation[2], rotation[3], rotation[4]))
            end
        end
        
        -- Apply config if available
        if config then
            -- Parse and apply vehicle configuration
            -- This depends on BeamMP's vehicle config system
            log("I", "HomeClaim", "Restoring vehicle " .. vehicleId .. " config")
        end
        
        log("I", "HomeClaim", "Restored vehicle " .. vehicleId .. " to saved position")
    else
        log("W", "HomeClaim", "Vehicle " .. vehicleId .. " not found for restoration")
    end
end

-- Restore multiple vehicles
local function restoreVehicles(vehicles)
    if not vehicles or #vehicles == 0 then
        return
    end
    
    log("I", "HomeClaim", "Restoring " .. #vehicles .. " vehicles")
    
    for _, vehicleData in ipairs(vehicles) do
        restoreVehicle(vehicleData)
    end
end

-- Event handlers
local function onHomeClaimCreateMarker(data)
    if data.position and data.radius and data.name then
        createRadiusMarker(
            vec3(data.position.x, data.position.y, data.position.z),
            data.radius,
            data.name
        )
    end
end

local function onHomeClaimRemoveMarker(data)
    -- Remove all markers
    for name, _ in pairs(markers) do
        removeRadiusMarker(name)
    end
    for name, _ in pairs(mapMarkers) do
        removeMapMarker(name)
    end
end

local function onHomeClaimUpdateMap(data)
    if data.homes then
        updateMapMarkers(data.homes)
    end
end

local function onHomeClaimRestoreVehicle(data)
    if data.vehicleId and data.position then
        restoreVehicle(data.vehicleId, data.position, data.config)
    end
end

-- Spawn a vehicle with the given config data
function onHomeClaimSpawnVehicle(data)
    log("I", "HomeClaim", "=== onHomeClaimSpawnVehicle CALLED ===")
    log("I", "HomeClaim", "Data type: " .. type(data))
    
    if type(data) == "table" then
        log("I", "HomeClaim", "Data keys: " .. table.concat({}, ", "))
        for k, v in pairs(data) do
            log("I", "HomeClaim", "  " .. tostring(k) .. " = " .. tostring(type(v)))
        end
    end
    
    -- Handle both JSON string and table format
    local configJson = nil
    if type(data) == "string" then
        configJson = data
        log("I", "HomeClaim", "Config is string, length: " .. string.len(configJson))
    elseif type(data) == "table" and data.config then
        configJson = data.config
        log("I", "HomeClaim", "Config from table, type: " .. type(configJson) .. ", length: " .. (type(configJson) == "string" and string.len(configJson) or "N/A"))
    else
        log("W", "HomeClaim", "Invalid data format for vehicle spawn. Data: " .. tostring(data))
        return
    end
    
    if not configJson or configJson == "" then
        log("W", "HomeClaim", "No config data provided for vehicle spawn")
        return
    end
    
    log("I", "HomeClaim", "Received vehicle spawn request, config length: " .. string.len(configJson))
    
    -- Parse config to extract position
    local jsonStart = string.find(configJson, "{")
    if jsonStart then
        configJson = string.sub(configJson, jsonStart, -1)
    end
    
    -- Use Util.JsonDecode if available, otherwise try jsonDecode
    local config = nil
    if Util and Util.JsonDecode then
        config = Util.JsonDecode(configJson)
    else
        -- Fallback - try to use global jsonDecode if it exists
        config = jsonDecode(configJson)
    end
    if not config then
        log("W", "HomeClaim", "Failed to parse vehicle config JSON")
        return
    end
    
    -- Extract position for setting after spawn
    local posX, posY, posZ = 0, 0, 0
    if config.pos and type(config.pos) == "table" and #config.pos >= 3 then
        posX = config.pos[1]
        posY = config.pos[2]
        posZ = config.pos[3]
    end
    
    -- Spawn vehicle using BeamNG API
    -- be:queueObjectSpawn expects a JSON string with the config
    local vehicleId = be:queueObjectSpawn(configJson)
    
    if vehicleId then
        log("I", "HomeClaim", "Vehicle queued for spawn with ID: " .. tostring(vehicleId))
        
        -- Set position after spawn (position is already in config, but we can also set it explicitly)
        if posX ~= 0 or posY ~= 0 or posZ ~= 0 then
            -- Use setObjectPosition if available, otherwise position should be in config
            if be.setObjectPosition then
                be:setObjectPosition(vehicleId, posX, posY, posZ)
                log("I", "HomeClaim", "Set vehicle position to " .. posX .. ", " .. posY .. ", " .. posZ)
            end
        end
    else
        log("W", "HomeClaim", "Failed to queue vehicle spawn")
    end
end

-- Enter vehicle at specified position
function onHomeClaimEnterVehicle(data)
    if not data.position then
        log("W", "HomeClaim", "onHomeClaimEnterVehicle called but no position data")
        return
    end
    
    log("I", "HomeClaim", "=== onHomeClaimEnterVehicle CALLED ===")
    log("I", "HomeClaim", "Position: " .. tostring(data.position.x) .. ", " .. tostring(data.position.y) .. ", " .. tostring(data.position.z))
    
    -- Use a timer callback instead of MP.Sleep (which might not work client-side)
    -- Wait a moment for vehicles to spawn, then try to enter
    local function tryEnterVehicle()
        log("I", "HomeClaim", "Attempting to enter vehicle at position")
    
    local targetPos = vec3(data.position.x, data.position.y, data.position.z)
    local vehicles = be:getAllVehicles()
    
    if not vehicles then
        log("W", "HomeClaim", "Could not get vehicles list")
        return
    end
    
    local closestVehicle = nil
    local closestDistance = 10 -- Max 10 meters
    
    for _, vehicle in ipairs(vehicles) do
        if vehicle then
            local vehPos = vehicle:getPosition()
            if vehPos then
                local distance = (vehPos - targetPos):length()
                
                if distance < closestDistance then
                    closestDistance = distance
                    closestVehicle = vehicle
                end
            end
        end
    end
    
        if closestVehicle then
            log("I", "HomeClaim", "Found vehicle near position, entering")
            be:enterVehicle(closestVehicle, 0) -- 0 = driver seat
        else
            log("W", "HomeClaim", "Could not find vehicle near position to enter (closest distance: " .. tostring(closestDistance) .. "m)")
        end
    end
    
    -- Use setTimer for delay (client-side equivalent)
    if setTimer then
        setTimer(tryEnterVehicle, 2000) -- 2 second delay
    else
        -- Fallback: try immediately
        log("W", "HomeClaim", "setTimer not available, trying immediately")
        tryEnterVehicle()
    end
end

-- Helper function to parse JSON data from event string
local function parseEventData(dataString)
    if not dataString or dataString == "" then
        return nil
    end
    
    -- Try to find JSON in the string (might have prefix)
    local jsonStart = string.find(dataString, "{")
    if jsonStart then
        dataString = string.sub(dataString, jsonStart, -1)
    end
    
    -- Try to decode JSON
    if Util and Util.JsonDecode then
        return Util.JsonDecode(dataString)
    elseif jsonDecode then
        return jsonDecode(dataString)
    else
        -- Fallback: try to parse manually or return raw string
        return dataString
    end
end

-- Wrapper functions to handle event data parsing
local function handleCreateMarker(dataString)
    local data = parseEventData(dataString)
    if data then
        onHomeClaimCreateMarker(data)
    end
end

local function handleRemoveMarker(dataString)
    onHomeClaimRemoveMarker({})
end

local function handleUpdateMap(dataString)
    local data = parseEventData(dataString)
    if data then
        onHomeClaimUpdateMap(data)
    end
end

local function handleSpawnVehicle(dataString)
    local data = parseEventData(dataString)
    if data then
        onHomeClaimSpawnVehicle(data)
    end
end

local function handleEnterVehicle(dataString)
    local data = parseEventData(dataString)
    if data then
        onHomeClaimEnterVehicle(data)
    end
end

-- Register client events using AddEventHandler (client-side mod API)
log("I", "HomeClaim", "Registering client events...")
AddEventHandler("homeClaim:createMarker", handleCreateMarker)
AddEventHandler("homeClaim:removeMarker", handleRemoveMarker)
AddEventHandler("homeClaim:updateMap", handleUpdateMap)
AddEventHandler("homeClaim:spawnVehicle", handleSpawnVehicle)
AddEventHandler("homeClaim:enterVehicle", handleEnterVehicle)
log("I", "HomeClaim", "Client events registered")

-- Cleanup on disconnect
AddEventHandler("onPlayerDisconnect", function()
    for name, _ in pairs(markers) do
        removeRadiusMarker(name)
    end
    for name, _ in pairs(mapMarkers) do
        removeMapMarker(name)
    end
end)

log("I", "HomeClaim", "Client plugin loaded successfully")

